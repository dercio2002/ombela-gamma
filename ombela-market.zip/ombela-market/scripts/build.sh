#!/bin/bash
mvn clean package
cd frontend
npm run build