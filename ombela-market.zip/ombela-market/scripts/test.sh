#!/bin/bash
mvn test
cd frontend
npm test