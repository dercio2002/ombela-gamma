# Ombela Market

A market application built with Spring Boot and React.

## Getting Started

### Prerequisites

- Java 17
- Node.js
- Maven

### Installation

1. Clone the repository
2. Run `./scripts/setup.sh`
3. Run `./scripts/build.sh`
4. Run `./scripts/test.sh`

## Usage

Start the backend: `./mvnw spring-boot:run`

Start the frontend: `cd frontend && npm start`

## Contributing

See CONTRIBUTING.md