#!/bin/bash
cd frontend
npm install
cd ..
mvn clean install